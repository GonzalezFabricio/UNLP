package ar.edu.unlp.info.cookbookv3;

import java.util.ArrayList;
import java.util.List;

public class Alumno {
	private int anioIngreso;
	private String nombre;
	private List<Examen> examenes;

	public Alumno(int anioIngreso, String nombre) {
		this.anioIngreso = anioIngreso;
		this.nombre = nombre;
		this.examenes = new ArrayList<>();
	}

	public int getAnioIngreso() {
		return this.anioIngreso;
	}

	public String getNombre() {
		return this.nombre;
	}

	public List<Examen> getExamenes() {
		return this.examenes;
	}

	/**
	 * Agrega un examen en la lista de examenes rendidos del alumno
	 *
	 * @param examen
	 */
	public void agregarExamen(Examen examen) {
		this.examenes.add(examen);
	}

	/**
	 * Permite consultar el promedio sin aplazos del alumno.
	 *
	 * @return el promedio sin tener en cuenta los examenes desaprobados
	 */
	public double promedioSinAplazos() {
		return this.examenes.stream()
				.filter(examen -> examen.estaAprobado())
				.mapToDouble(examen -> examen.getNota())
				.average()
				.orElse(0);
	}

	/**
	 * Permite consultar el promedio del alumno.
	 *
	 * @return el promedio, teniendo en cuenta todos los exámenes rendidos
	 */
	public double promedio() {
		return this.examenes.stream()
				.mapToDouble(examen -> examen.getNota())
				.average()
				.orElse(0);
	}

	/**
	 * Permite consultar la cantidad de exámenes rendidos en un año dado.
	 *
	 * @param anio
	 * @return
	 */
	public int cantidadExamenesRendidos(int anio) {
		return (int) this.examenes.stream()
				.filter(examen -> examen.rendidoElAnio(anio))
				.count();
	}
}
