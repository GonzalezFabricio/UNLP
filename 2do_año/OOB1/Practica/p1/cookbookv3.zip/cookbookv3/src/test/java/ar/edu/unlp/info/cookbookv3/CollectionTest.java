package ar.edu.unlp.info.cookbookv3;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CollectionTest {
	Alumno rodrigo, joel, matias, amalia;
	List<Alumno> alumnos;

	@BeforeEach
	void setUp() {
		// se instancian y agregan cuatro alumnos con algunos examenes rendidos
		this.rodrigo = new Alumno(2020, "Rodrigo");
		this.rodrigo.agregarExamen(new Examen(9, "Mate 1", LocalDate.of(2020, 9, 10)));
		this.rodrigo.agregarExamen(new Examen(9, "Mate 2", LocalDate.of(2021, 9, 10)));

		this.joel = new Alumno(2020, "Joel");
		this.joel.agregarExamen(new Examen(3, "Mate 2", LocalDate.of(2020, 9, 10)));
		this.joel.agregarExamen(new Examen(7, "OO1", LocalDate.of(2020, 9, 10)));

		this.matias = new Alumno(2021, "Matias");
		this.matias.agregarExamen(new Examen(10, "Mate 2", LocalDate.of(2021, 9, 10)));
		this.matias.agregarExamen(new Examen(10, "OO1", LocalDate.of(2021, 9, 10)));

		this.amalia = new Alumno(2022, "Amalia");
		this.amalia.agregarExamen(new Examen(6, "Mate 2", LocalDate.of(2022, 9, 10)));
		this.amalia.agregarExamen(new Examen(7, "OO2", LocalDate.of(2022, 9, 10)));

		this.alumnos = new ArrayList<>();
		this.alumnos.add(this.rodrigo);
		this.alumnos.add(this.joel);
		this.alumnos.add(this.matias);
		this.alumnos.add(this.amalia);
	}

	@Test
	public void testIngresantesEnAnio2020() {
		// rodrigo y joel son los únicos alumnos ingresantes del 2020.
		List<Alumno> alumnos2020Esperados = Arrays.asList(this.rodrigo, this.joel);
		List<Alumno> alumnosIngresantes2020 = this.alumnos.stream()
				.filter(alumno -> alumno.getAnioIngreso() == 2020)
				.collect(Collectors.toList());
		assertEquals(alumnos2020Esperados, alumnosIngresantes2020);
	}

	@Test
	public void testNombresAlumnos() {
		List<String> nombresAlumnosEsperados = Arrays.asList("Rodrigo", "Joel", "Matias", "Amalia");
		List<String> nombresAlumnos = this.alumnos.stream()
				.map(alumno -> alumno.getNombre())
				.collect(Collectors.toList());
		assertEquals(nombresAlumnosEsperados, nombresAlumnos);
	}

	@Test
	public void testPrimerosTresAlumnos() {
		List<Alumno> primerosTresEsperados = Arrays.asList(this.rodrigo, this.joel, this.matias);
		List<Alumno> primerosTres = this.alumnos.stream()
				.limit(3)
				.collect(Collectors.toList());
		assertEquals(primerosTresEsperados, primerosTres);
	}

	@Test
	public void testAlumnosOrdenadosPorPromedioAsc() {
		List<Alumno> alumnosOrdenEsperado = Arrays.asList(this.joel, this.amalia, this.rodrigo, this.matias);
		List<Alumno> alumnosOrdenados = this.alumnos.stream()
				.sorted((a1, a2) -> Double.compare(a1.promedio(), a2.promedio()))
				.collect(Collectors.toList());
		assertEquals(alumnosOrdenEsperado, alumnosOrdenados);
	}

	@Test
	public void testAlumnosOrdenadosPorPromedioDesc() {
		List<Alumno> alumnosOrdenDescEsperado = Arrays.asList(this.matias, this.rodrigo, this.amalia, this.joel);
		List<Alumno> alumnosPromedioDesc = this.alumnos.stream()
				.sorted((a1, a2) -> Double.compare(a2.promedio(), a1.promedio()))
				.collect(Collectors.toList());
		assertEquals(alumnosOrdenDescEsperado, alumnosPromedioDesc);
	}

	@Test
	public void testTotalExamenesTomadosEn2020() {
		int totalExamenesTomados2020 = this.alumnos.stream()
				.mapToInt(alumno -> alumno.cantidadExamenesRendidos(2020))
				.sum();
		assertEquals(3, totalExamenesTomados2020);
	}

	@Test
	public void testCantidadDeAlumnosConPromediosMayorA8() {
		int cantidadAlumnosPromedioMayorA8 = (int) this.alumnos.stream()
				.filter(alumno -> alumno.promedio() >= 8)
				.count();
		assertEquals(2, cantidadAlumnosPromedioMayorA8);
	}

	@Test
	public void testExisteIngresanteAntesDe2021() {
		boolean ingresantesAntes2021 = this.alumnos.stream()
				.anyMatch(alumno -> alumno.getAnioIngreso() < 2021);
		assertTrue(ingresantesAntes2021);
	}

	@Test
	public void testMejorPromedio() {
		Alumno mejorPromedio = this.alumnos.stream()
				.max((a1, a2) -> Double.compare(a1.promedio(), a2.promedio()))
				.orElse(null);
		assertEquals(this.matias, mejorPromedio);
	}

	@Test
	public void testPrimerAlumnoConM() {
		Alumno primerAlumnoNombreConLetraM = this.alumnos.stream()
				.filter(alumno -> alumno.getNombre().startsWith("M"))
				.findFirst()
				.orElse(null);
		assertEquals(this.matias, primerAlumnoNombreConLetraM);
	}

	@Test
	public void testMateriasCursadas() {
		List<String> materiasEsperadas = Arrays.asList("Mate 1", "Mate 2", "OO1", "OO2");
		List<String> materiasDistintas = this.alumnos.stream()
				.flatMap(alumno -> alumno.getExamenes().stream())
				.map(examen -> examen.getMateria())
				.distinct()
				.collect(Collectors.toList());
		assertEquals(materiasEsperadas, materiasDistintas);
	}
}
